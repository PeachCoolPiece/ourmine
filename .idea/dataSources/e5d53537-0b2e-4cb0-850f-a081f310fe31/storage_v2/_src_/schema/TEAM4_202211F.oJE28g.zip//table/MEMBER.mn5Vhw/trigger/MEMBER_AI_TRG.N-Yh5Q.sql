create trigger MEMBER_AI_TRG
    before insert
    on MEMBER
    for each row
BEGIN
     SELECT MEMBER_SEQ.NEXTVAL
     INTO :NEW.MEMBER_ID
     FROM DUAL;
 END;
/

