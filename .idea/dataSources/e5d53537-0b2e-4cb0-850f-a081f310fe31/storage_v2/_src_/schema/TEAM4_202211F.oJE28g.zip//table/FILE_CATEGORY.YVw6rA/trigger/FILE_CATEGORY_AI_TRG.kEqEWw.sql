create trigger FILE_CATEGORY_AI_TRG
    before insert
    on FILE_CATEGORY
    for each row
BEGIN
    SELECT FILE_CATEGORY_SEQ.NEXTVAL
    INTO :NEW.FILE_CATEGORY_ID
    FROM DUAL;
END;
/

