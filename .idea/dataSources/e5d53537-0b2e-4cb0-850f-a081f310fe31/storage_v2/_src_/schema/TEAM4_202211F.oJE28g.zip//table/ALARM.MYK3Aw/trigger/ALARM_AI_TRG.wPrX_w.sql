create trigger ALARM_AI_TRG
    before insert
    on ALARM
    for each row
BEGIN
    SELECT ALARM_SEQ.NEXTVAL
    INTO :NEW.ALARM_ID
    FROM DUAL;
END;
/

