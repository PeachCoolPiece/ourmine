create trigger BOARD_FILE_AI_TRG
    before insert
    on BOARD_FILE
    for each row
BEGIN
    SELECT BOARD_FILE_SEQ.NEXTVAL
    INTO :NEW.BOARD_FILE_ID
    FROM DUAL;
END;
/

