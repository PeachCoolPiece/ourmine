create trigger PROJECT_TODO_LIST_AI_TRG
    before insert
    on PROJECT_TODO_LIST
    for each row
BEGIN
    SELECT PROJECT_TODO_LIST_SEQ.NEXTVAL
    INTO :NEW.TODO_ID
    FROM DUAL;
END;
/

