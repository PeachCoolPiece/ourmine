create trigger CODE_EDITOR_AI_TRG
    before insert
    on CODE_EDITOR
    for each row
BEGIN
    SELECT CODE_EDITOR_SEQ.NEXTVAL
    INTO :NEW.CODE_EDITOR_ID
    FROM DUAL;
END;
/

