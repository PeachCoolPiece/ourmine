create trigger BOARD_TYPE_AI_TRG
    before insert
    on BOARD_TYPE
    for each row
BEGIN
    SELECT BOARD_TYPE_SEQ.NEXTVAL
    INTO :NEW.BOARD_TYPE_ID
    FROM DUAL;
END;
/

