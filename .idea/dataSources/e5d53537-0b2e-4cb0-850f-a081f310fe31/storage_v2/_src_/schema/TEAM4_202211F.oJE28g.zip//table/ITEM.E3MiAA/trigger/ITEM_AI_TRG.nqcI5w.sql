create trigger ITEM_AI_TRG
    before insert
    on ITEM
    for each row
BEGIN
    SELECT ITEM_SEQ.NEXTVAL
    INTO :NEW.ITEM_ID
    FROM DUAL;
END;
/

