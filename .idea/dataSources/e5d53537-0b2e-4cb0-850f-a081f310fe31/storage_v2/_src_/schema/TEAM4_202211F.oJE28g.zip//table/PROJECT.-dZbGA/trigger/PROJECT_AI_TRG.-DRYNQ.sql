create trigger PROJECT_AI_TRG
    before insert
    on PROJECT
    for each row
BEGIN
    SELECT PROJECT_SEQ.NEXTVAL
    INTO :NEW.PROJECT_ID
    FROM DUAL;
END;
/

