create trigger MEMBER_GRADE_AI_TRG
    before insert
    on MEMBER_GRADE
    for each row
BEGIN
    SELECT MEMBER_GRADE_SEQ.NEXTVAL
    INTO :NEW.MEMBER_GRADE_ID
    FROM DUAL;
END;
/

