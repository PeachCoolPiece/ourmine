create trigger PROJECT_WORK_AI_TRG
    before insert
    on PROJECT_WORK
    for each row
BEGIN
    SELECT PROJECT_WORK_SEQ.NEXTVAL
    INTO :NEW.PROJECT_WORK_ID
    FROM DUAL;
END;
/

