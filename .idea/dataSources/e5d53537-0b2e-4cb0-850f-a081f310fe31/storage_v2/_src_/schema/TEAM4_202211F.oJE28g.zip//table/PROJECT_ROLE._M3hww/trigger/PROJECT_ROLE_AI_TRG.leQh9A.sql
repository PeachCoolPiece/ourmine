create trigger PROJECT_ROLE_AI_TRG
    before insert
    on PROJECT_ROLE
    for each row
BEGIN
    SELECT PROJECT_ROLE_SEQ.NEXTVAL
    INTO :NEW.PROJECT_ROLE_ID
    FROM DUAL;
END;
/

