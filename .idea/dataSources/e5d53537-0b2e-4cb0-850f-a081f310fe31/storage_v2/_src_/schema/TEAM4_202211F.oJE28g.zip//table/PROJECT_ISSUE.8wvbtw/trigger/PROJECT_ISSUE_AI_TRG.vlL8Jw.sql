create trigger PROJECT_ISSUE_AI_TRG
    before insert
    on PROJECT_ISSUE
    for each row
BEGIN
    SELECT PROJECT_ISSUE_SEQ.NEXTVAL
    INTO :NEW.PROJECT_ISSUE_ID
    FROM DUAL;
END;
/

