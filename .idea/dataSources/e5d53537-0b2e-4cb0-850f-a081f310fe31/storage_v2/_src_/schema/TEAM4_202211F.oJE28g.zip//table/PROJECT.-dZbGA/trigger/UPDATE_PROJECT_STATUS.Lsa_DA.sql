create trigger UPDATE_PROJECT_STATUS
    before update
    on PROJECT
    for each row
BEGIN
  IF :NEW.PROJECT_END_DATE <= SYSDATE THEN
    :NEW.PROJECT_STATUS_ID := 2;
  END IF;
END;
/

