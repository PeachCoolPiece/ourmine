create trigger GIT_AI_TRG
    before insert
    on GIT
    for each row
BEGIN
    SELECT GIT_SEQ.NEXTVAL
    INTO :NEW.GIT_ID
    FROM DUAL;
END;
/

