create trigger COMPANY_AI_TRG
    before insert
    on COMPANY
    for each row
BEGIN
    SELECT COMPANY_SEQ.NEXTVAL
    INTO :NEW.COMPANY_ID
    FROM DUAL;
END;
/

