create trigger PULL_REQUESTS_AI_TRG
    before insert
    on PULL_REQUESTS
    for each row
BEGIN
    SELECT PULL_REQUESTS_SEQ.NEXTVAL
    INTO :NEW.FULL_REQUESTS_ID
    FROM DUAL;
END;
/

