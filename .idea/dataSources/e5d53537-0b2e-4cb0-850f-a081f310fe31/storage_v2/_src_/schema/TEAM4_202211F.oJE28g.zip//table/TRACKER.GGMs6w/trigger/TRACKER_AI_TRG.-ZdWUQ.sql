create trigger TRACKER_AI_TRG
    before insert
    on TRACKER
    for each row
BEGIN
    SELECT TRACKER_SEQ.NEXTVAL
    INTO :NEW.TRACKER_ID
    FROM DUAL;
END;
/

