create trigger BOARD_REPLY_AI_TRG
    before insert
    on BOARD_REPLY
    for each row
BEGIN
    SELECT BOARD_REPLE_SEQ.NEXTVAL
    INTO :NEW.REPLY_ID
    FROM DUAL;
END;
/

