create trigger SUBSCRIBE_AI_TRG
    before insert
    on SUBSCRIBE
    for each row
BEGIN
    SELECT SUBSCRIBE_SEQ.NEXTVAL
    INTO :NEW.SUBSCRIBE_ID
    FROM DUAL;
END;
/

