create trigger WAITING_LIST_AI_TRG
    before insert
    on WAITING_LIST
    for each row
BEGIN
    SELECT WAITING_LIST_SEQ.NEXTVAL
    INTO :NEW.WAITING_LIST_ID
    FROM DUAL;
END;
/

