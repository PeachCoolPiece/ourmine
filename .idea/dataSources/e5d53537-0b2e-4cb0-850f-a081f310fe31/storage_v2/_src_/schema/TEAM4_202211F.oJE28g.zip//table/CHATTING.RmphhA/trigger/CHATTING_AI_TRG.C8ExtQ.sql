create trigger CHATTING_AI_TRG
    before insert
    on CHATTING
    for each row
BEGIN 
    SELECT CHATTING_SEQ.NEXTVAL
    INTO :NEW.CHATTING_ID
    FROM DUAL;
END;
/

