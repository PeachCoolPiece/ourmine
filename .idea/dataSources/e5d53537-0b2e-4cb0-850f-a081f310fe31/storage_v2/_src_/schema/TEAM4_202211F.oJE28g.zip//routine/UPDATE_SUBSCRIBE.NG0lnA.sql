create PROCEDURE UPDATE_SUBSCRIBE AS
 BEGIN 
      UPDATE SUBSCRIBE 
         SET SUBSCRIBE_USE = 'N'
       WHERE SUBSCRIBE_END_DATE = SYSDATE;
 END UPDATE_SUBSCRIBE;


BEGIN
 DBMS_SCHEDULER.CREATE_JOB(
        job_name => '"TEAM4_202211F"."JOB_UPDATE_SUBSCRIBE"',
        job_type => 'STORED_PROCEDURE',
        job_action => 'TEAM4_202211F.UPDATE_SUBSCRIBE',
        start_date => NULL,
        repeat_interval => 'TRUNC(SYSDATE+1)',
        end_date => NULL,
        enabled => false,
        comments => '구독기한업데이트'
    );
  END;
/

