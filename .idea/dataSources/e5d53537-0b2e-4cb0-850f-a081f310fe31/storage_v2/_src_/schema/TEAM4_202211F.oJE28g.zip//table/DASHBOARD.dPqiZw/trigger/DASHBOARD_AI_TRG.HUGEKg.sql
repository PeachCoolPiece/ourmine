create trigger DASHBOARD_AI_TRG
    before insert
    on DASHBOARD
    for each row
BEGIN
    SELECT DASHBOARD_SEQ.NEXTVAL
    INTO :NEW.DASHBOARD_ID
    FROM DUAL;
END;
/

