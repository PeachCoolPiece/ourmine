create trigger BOARD_AI_TRG
    before insert
    on BOARD
    for each row
BEGIN
    SELECT BOARD_SEQ.NEXTVAL
    INTO :NEW.BOARD_ID
    FROM DUAL;
END;
/

