create trigger MEMBER_IMAGE_AI_TRG
    before insert
    on MEMBER_IMAGE
    for each row
BEGIN
    SELECT MEMBER_IMAGE_SEQ.NEXTVAL
    INTO :NEW.MEMBER_IMAGE_ID
    FROM DUAL;
END;
/

