create trigger ORGCHART_AI_TRG
    before insert
    on ORGCHART
    for each row
BEGIN
    SELECT ORGCHART_SEQ.NEXTVAL
    INTO :NEW.ORGCHART_ID
    FROM DUAL;
END;
/

