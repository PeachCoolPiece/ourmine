create trigger NOTICE_BOARD_AI_TRG
    before insert
    on NOTICE_BOARD
    for each row
BEGIN
    SELECT NOTICE_BOARD_SEQ.NEXTVAL
    INTO :NEW.NOTICE_BOARD_WRITE_ID
    FROM DUAL;
END;
/

